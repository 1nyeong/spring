package com.study.mvc20220927h;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mvc20220927HApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mvc20220927HApplication.class, args);
	}

}
