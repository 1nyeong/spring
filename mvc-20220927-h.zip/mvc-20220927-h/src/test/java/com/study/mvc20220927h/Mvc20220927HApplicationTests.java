package com.study.mvc20220927h;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mvc20220927HApplicationTests {

	@Test
	void contextLoads() {
	}

}
